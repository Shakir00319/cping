package com.pingguard

import java.io.*
import java.net.InetSocketAddress
import java.net.Socket

class ApiException(msg: String) : Exception(msg)

/** Minimal client for the MikroTik RouterOS API (plain, default port 8728). Needs RouterOS 6.43+. */
class RouterOsApi(private val host: String, private val port: Int = 8728) : Closeable {
    private val socket = Socket()
    private lateinit var input: InputStream
    private lateinit var output: OutputStream

    private fun ensureConnected() {
        if (socket.isConnected) return
        socket.connect(InetSocketAddress(host, port), 10_000)
        socket.soTimeout = 40_000
        input = BufferedInputStream(socket.getInputStream())
        output = BufferedOutputStream(socket.getOutputStream())
    }

    fun login(user: String, pass: String) {
        ensureConnected()
        val reply = command(listOf("/login", "=name=$user", "=password=$pass"))
        if (reply.any { s -> s.any { it.startsWith("=ret=") } })
            throw ApiException("RouterOS older than 6.43 is not supported")
    }

    /** Runs /ping from the router to [target]; returns packet loss in percent. */
    fun ping(target: String, count: Int): Int {
        val rows = command(listOf("/ping", "=address=$target", "=count=$count"))
            .filter { it.isNotEmpty() && it[0] == "!re" }
        if (rows.isEmpty()) throw ApiException("Router returned no ping data")
        val last = rows.last()
        attr(last, "packet-loss")?.toIntOrNull()?.let { return it }
        val sent = attr(last, "sent")?.toIntOrNull() ?: count
        val received = attr(last, "received")?.toIntOrNull() ?: 0
        return if (sent <= 0) 100 else ((sent - received) * 100) / sent
    }

    private fun attr(sentence: List<String>, key: String): String? =
        sentence.firstOrNull { it.startsWith("=$key=") }?.substring(key.length + 2)

    private fun command(words: List<String>): List<List<String>> {
        writeSentence(words)
        val all = ArrayList<List<String>>()
        var error: String? = null
        while (true) {
            val s = readSentence()
            if (s.isEmpty()) continue
            when (s[0]) {
                "!done" -> { all.add(s); break }
                "!trap" -> error = attr(s, "message") ?: "Router refused the command"
                "!fatal" -> throw ApiException(s.drop(1).joinToString(" ").ifEmpty { "Router closed the connection" })
                else -> all.add(s)
            }
        }
        if (error != null) throw ApiException(error)
        return all
    }

    private fun writeSentence(words: List<String>) {
        for (w in words) {
            val b = w.toByteArray(Charsets.UTF_8)
            writeLen(b.size)
            output.write(b)
        }
        output.write(0)
        output.flush()
    }

    private fun writeLen(len: Int) {
        when {
            len < 0x80 -> output.write(len)
            len < 0x4000 -> { val l = len or 0x8000; output.write(l shr 8); output.write(l) }
            len < 0x200000 -> { val l = len or 0xC00000; output.write(l shr 16); output.write(l shr 8); output.write(l) }
            else -> { val l = len or 0xE0000000.toInt(); output.write(l ushr 24); output.write(l shr 16); output.write(l shr 8); output.write(l) }
        }
    }

    private fun readByte(): Int {
        val c = input.read()
        if (c < 0) throw EOFException("Router closed the connection")
        return c
    }

    private fun readLen(): Int {
        var c = readByte()
        if ((c and 0x80) == 0) return c
        if ((c and 0xC0) == 0x80) { c = c and 0x3F; return (c shl 8) or readByte() }
        if ((c and 0xE0) == 0xC0) { c = c and 0x1F; c = (c shl 8) or readByte(); return (c shl 8) or readByte() }
        if ((c and 0xF0) == 0xE0) { c = c and 0x0F; repeat(3) { c = (c shl 8) or readByte() }; return c }
        var r = 0
        repeat(4) { r = (r shl 8) or readByte() }
        return r
    }

    private fun readSentence(): List<String> {
        val words = ArrayList<String>()
        while (true) {
            val len = readLen()
            if (len == 0) return words
            val buf = ByteArray(len)
            var off = 0
            while (off < len) {
                val n = input.read(buf, off, len - off)
                if (n < 0) throw EOFException("Router closed the connection")
                off += n
            }
            words.add(String(buf, Charsets.UTF_8))
        }
    }

    override fun close() { try { socket.close() } catch (_: Exception) {} }
}
