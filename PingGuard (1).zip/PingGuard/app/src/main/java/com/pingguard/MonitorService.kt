package com.pingguard

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

class MonitorService : Service() {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var wakeLock: PowerManager.WakeLock? = null
    private var alerted = false

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("status", "Monitor status", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("alert", "Packet loss alerts", NotificationManager.IMPORTANCE_HIGH))
        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mikrowatch:monitor").apply { acquire() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = statusNotification("Starting...")
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        scope.coroutineContext.cancelChildren()
        scope.launch { loop() }
        return START_STICKY
    }

    private suspend fun loop() {
        val p = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        while (currentCoroutineContext().isActive) {
            if (!p.getBoolean("enabled", false)) { stopSelf(); return }
            val host = p.getString("host", "")!!
            val port = p.getInt("port", 8728)
            val user = p.getString("user", "")!!
            val pass = p.getString("pass", "")!!
            val target = p.getString("target", "8.8.8.8")!!
            val interval = p.getInt("interval", 30).coerceAtLeast(10)
            val threshold = p.getInt("threshold", 20).coerceIn(1, 100)

            var bad: Boolean
            var title: String
            var text: String
            try {
                val loss = RouterOsApi(host, port).use { it.login(user, pass); it.ping(target, 10) }
                bad = loss >= threshold
                title = "Packet loss detected"
                text = "Router -> $target: $loss% packet loss"
            } catch (e: Exception) {
                bad = true
                title = "Router unreachable"
                text = "Can't reach router: ${e.message ?: e.javaClass.simpleName}"
            }

            p.edit().putString("status", text).putBoolean("bad", bad)
                .putLong("time", System.currentTimeMillis()).apply()
            getSystemService(NotificationManager::class.java).notify(1, statusNotification(text))

            if (bad && !alerted) { alert(title, text); alerted = true }
            else if (!bad && alerted) { alert("Connection OK again", text); alerted = false }

            delay(interval * 1000L)
        }
    }

    private fun openApp() = PendingIntent.getActivity(
        this, 0, Intent(this, StatusActivity::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun statusNotification(text: String) = NotificationCompat.Builder(this, "status")
        .setSmallIcon(android.R.drawable.stat_notify_sync).setContentTitle("MikroWatch running")
        .setContentText(text).setOngoing(true).setContentIntent(openApp()).build()

    private fun alert(title: String, text: String) {
        val n = NotificationCompat.Builder(this, "alert")
            .setSmallIcon(android.R.drawable.stat_sys_warning).setContentTitle(title).setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_MAX).setCategory(NotificationCompat.CATEGORY_ALARM)
            .setDefaults(Notification.DEFAULT_ALL).setAutoCancel(true).setContentIntent(openApp()).build()
        getSystemService(NotificationManager::class.java).notify(System.currentTimeMillis().toInt(), n)
    }

    override fun onDestroy() { scope.cancel(); wakeLock?.release(); super.onDestroy() }
    override fun onBind(i: Intent?): IBinder? = null
}
