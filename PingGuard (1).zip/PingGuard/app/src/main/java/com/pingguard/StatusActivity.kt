package com.pingguard

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class StatusActivity : AppCompatActivity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var big: TextView
    private lateinit var detail: TextView
    private val tick = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 1000) } }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        big = TextView(this).apply { textSize = 22f; gravity = Gravity.CENTER; setPadding(0, dp(32), 0, dp(12)) }
        detail = TextView(this).apply { textSize = 15f; gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(32)) }
        val battery = Button(this).apply { text = "Allow background running (battery)"; setOnClickListener {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } }
        val logout = Button(this).apply { text = "Stop & log out"; setOnClickListener {
            p.edit().putBoolean("enabled", false).remove("pass").apply()
            stopService(Intent(this@StatusActivity, MonitorService::class.java))
            startActivity(Intent(this@StatusActivity, LoginActivity::class.java))
            finish()
        } }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
            addView(TextView(context).apply { text = "MikroWatch"; textSize = 28f; gravity = Gravity.CENTER })
            listOf(big, detail, battery, logout).forEach { addView(it) }
        })
    }

    private fun refresh() {
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val t = p.getLong("time", 0L)
        val bad = p.getBoolean("bad", false)
        big.text = if (t == 0L) "Connecting..." else if (bad) "PROBLEM" else "ALL GOOD"
        big.setTextColor(if (t == 0L) Color.GRAY else if (bad) Color.parseColor("#E53935") else Color.parseColor("#43A047"))
        val ago = if (t == 0L) "" else "\nLast check ${(System.currentTimeMillis() - t) / 1000}s ago"
        detail.text = "${p.getString("host", "")}\n${p.getString("status", "")}$ago"
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
