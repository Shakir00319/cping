package com.pingguard

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class LoginActivity : AppCompatActivity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        if (p.getBoolean("enabled", false)) {
            startActivity(Intent(this, StatusActivity::class.java)); finish(); return
        }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        fun field(hint: String, value: String = "", type: Int = InputType.TYPE_CLASS_TEXT) = EditText(this).apply {
            this.hint = hint; setText(value); inputType = type; setSingleLine()
        }
        val saved = p.getString("host", "") ?: ""
        val address = field("Address (IP or VPN address)", saved, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        val user = field("Username", p.getString("user", "") ?: "")
        val pass = field("Password", "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        val target = field("Ping target (checked from the router)", p.getString("target", "8.8.8.8") ?: "8.8.8.8")
        val interval = field("Check every (seconds)", p.getInt("interval", 30).toString(), InputType.TYPE_CLASS_NUMBER)
        val threshold = field("Alert when loss is at least (%)", p.getInt("threshold", 20).toString(), InputType.TYPE_CLASS_NUMBER)
        val msg = TextView(this).apply { textSize = 14f }
        val connect = Button(this).apply { text = "Connect & start monitoring" }

        connect.setOnClickListener {
            val (host, port) = parseAddress(address.text.toString().trim())
            val u = user.text.toString().trim()
            val pw = pass.text.toString()
            if (host.isEmpty() || u.isEmpty()) { msg.text = "Enter the address and username."; return@setOnClickListener }
            connect.isEnabled = false
            msg.text = "Connecting..."
            Thread {
                val err = try { RouterOsApi(host, port).use { it.login(u, pw) }; null }
                catch (e: Exception) { e.message ?: e.javaClass.simpleName }
                runOnUiThread {
                    connect.isEnabled = true
                    if (err != null) { msg.text = "Failed: $err"; return@runOnUiThread }
                    p.edit().putString("host", host).putInt("port", port).putString("user", u)
                        .putString("pass", pw).putString("target", target.text.toString().trim().ifEmpty { "8.8.8.8" })
                        .putInt("interval", interval.text.toString().toIntOrNull() ?: 30)
                        .putInt("threshold", threshold.text.toString().toIntOrNull() ?: 20)
                        .putBoolean("enabled", true).putString("status", "Starting...").putBoolean("bad", false)
                        .putLong("time", 0L).apply()
                    ContextCompat.startForegroundService(this, Intent(this, MonitorService::class.java))
                    startActivity(Intent(this, StatusActivity::class.java))
                    finish()
                }
            }.start()
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
            addView(TextView(context).apply { text = "MikroWatch"; textSize = 28f })
            addView(TextView(context).apply { text = "Log in to your MikroTik (API port 8728)"; setPadding(0, dp(4), 0, dp(16)) })
            listOf(address, user, pass).forEach { addView(it) }
            addView(TextView(context).apply { text = "Monitoring settings"; setPadding(0, dp(20), 0, 0) })
            listOf(target, interval, threshold, connect, msg).forEach { addView(it) }
        }
        setContentView(ScrollView(this).apply {
            addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
    }

    /** "host" or "host:port" -> (host, port). Default API port is 8728. */
    private fun parseAddress(a: String): Pair<String, Int> {
        val s = a.removePrefix("http://").removePrefix("https://").trimEnd('/')
        val i = s.lastIndexOf(':')
        if (i > 0 && s.indexOf(':') == i) {
            val port = s.substring(i + 1).toIntOrNull()
            if (port != null) return s.substring(0, i) to port
        }
        return s to 8728
    }
}
