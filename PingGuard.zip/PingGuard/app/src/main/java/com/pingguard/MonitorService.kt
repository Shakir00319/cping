package com.pingguard

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

class MonitorService : Service() {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var wakeLock: PowerManager.WakeLock? = null
    private var alerted = false

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("status", "Monitor status", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("alert", "Packet loss alerts", NotificationManager.IMPORTANCE_HIGH))
        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "pingguard:monitor").apply { acquire() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, status("Starting..."), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        scope.coroutineContext.cancelChildren()
        scope.launch { loop() }
        return START_STICKY
    }

    private suspend fun loop() {
        val p = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        while (true) {
            val host = p.getString("host", "10.0.0.1")!!
            val interval = p.getInt("interval", 30)
            val threshold = p.getInt("threshold", 20) // % loss that triggers alert
            val loss = ping(host, 10)
            val msg = if (loss < 0) "$host: unreachable (is VPN up?)" else "$host: ${loss}% loss"
            getSystemService(NotificationManager::class.java).notify(1, status(msg))
            val bad = loss < 0 || loss >= threshold
            if (bad && !alerted) { alert("Router problem", msg); alerted = true }
            if (!bad && alerted) { alert("Router recovered", msg); alerted = false }
            delay(interval * 1000L)
        }
    }

    /** Returns packet loss % (0-100), or -1 if ping could not run / no reply at all. */
    private fun ping(host: String, count: Int): Int = try {
        val proc = ProcessBuilder("/system/bin/ping", "-c", "$count", "-i", "0.3", "-W", "1", host)
            .redirectErrorStream(true).start()
        val out = proc.inputStream.bufferedReader().readText()
        proc.waitFor()
        Regex("""(\d+)% packet loss""").find(out)?.groupValues?.get(1)?.toInt() ?: -1
    } catch (e: Exception) { -1 }

    private fun status(text: String) = NotificationCompat.Builder(this, "status")
        .setSmallIcon(android.R.drawable.stat_notify_sync).setContentTitle("PingGuard running")
        .setContentText(text).setOngoing(true).build()

    private fun alert(title: String, text: String) {
        val n = NotificationCompat.Builder(this, "alert")
            .setSmallIcon(android.R.drawable.stat_sys_warning).setContentTitle(title).setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_MAX).setCategory(NotificationCompat.CATEGORY_ALARM)
            .setDefaults(Notification.DEFAULT_ALL).setAutoCancel(true).build()
        getSystemService(NotificationManager::class.java).notify(System.currentTimeMillis().toInt(), n)
    }

    override fun onDestroy() { scope.cancel(); wakeLock?.release(); super.onDestroy() }
    override fun onBind(i: Intent?): IBinder? = null
}
