package com.pingguard

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)

        fun field(hint: String, value: String, num: Boolean = false) = EditText(this).apply {
            this.hint = hint; setText(value)
            if (num) inputType = InputType.TYPE_CLASS_NUMBER
        }
        val host = field("Router IP (inside VPN), e.g. 10.0.0.1", p.getString("host", "")!!)
        val interval = field("Check every N seconds", p.getInt("interval", 30).toString(), true)
        val threshold = field("Alert at loss % (e.g. 20)", p.getInt("threshold", 20).toString(), true)

        fun save() = p.edit().putString("host", host.text.toString().trim())
            .putInt("interval", interval.text.toString().toIntOrNull() ?: 30)
            .putInt("threshold", threshold.text.toString().toIntOrNull() ?: 20).apply()

        val start = Button(this).apply { text = "Start monitoring"; setOnClickListener {
            save(); p.edit().putBoolean("enabled", true).apply()
            ContextCompat.startForegroundService(this@MainActivity, Intent(this@MainActivity, MonitorService::class.java))
        } }
        val stop = Button(this).apply { text = "Stop"; setOnClickListener {
            p.edit().putBoolean("enabled", false).apply()
            stopService(Intent(this@MainActivity, MonitorService::class.java))
        } }
        val battery = Button(this).apply { text = "Disable battery optimization"; setOnClickListener {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } }
        val vpn = Button(this).apply { text = "Open VPN settings"; setOnClickListener {
            startActivity(Intent(Settings.ACTION_VPN_SETTINGS))
        } }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48)
            listOf(host, interval, threshold, start, stop, battery, vpn).forEach { addView(it) }
        })
    }
}
