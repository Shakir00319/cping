package com.oldplace.mikroping

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import android.graphics.Color
import android.text.InputType

class MainActivity : Activity() {
    private fun field(hint: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText {
        return EditText(this).apply {
            this.hint = hint
            inputType = type
            setSingleLine(true)
            textSize = 15f
            setPadding(18, 12, 18, 12)
            setBackgroundColor(Color.rgb(245,247,250))
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(Color.WHITE)
        }
        val title = TextView(this).apply {
            text = "MikroTik\nM I K R O P I N G"
            textSize = 25f; gravity = Gravity.CENTER; setTextColor(Color.rgb(25,35,48))
        }
        page.addView(title, LinearLayout.LayoutParams(-1, 110))
        fun label(t: String) { page.addView(TextView(this).apply {
            text=t; textSize=13f; setTextColor(Color.DKGRAY); setPadding(2,12,0,3)
        }) }
        label("Router remote IP / DDNS")
        val host = field("e.g. router.example.com")
        page.addView(host)
        label("API-SSL port")
        val port = field("8729", InputType.TYPE_CLASS_NUMBER); page.addView(port)
        label("MikroTik username")
        val user = field("admin"); page.addView(user)
        label("MikroTik password")
        val pass = field("Password", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        page.addView(pass)
        label("Server / destination IP to monitor")
        val target = field("e.g. 1.1.1.1"); page.addView(target)
        val status = TextView(this).apply {
            text = "Monitoring is stopped"; textSize=14f; setTextColor(Color.DKGRAY); setPadding(0,18,0,12)
        }
        page.addView(status)
        val start = Button(this).apply { text = "START 24/7 MONITORING" }
        page.addView(start, LinearLayout.LayoutParams(-1, 54))
        val stop = Button(this).apply { text = "STOP MONITORING" }
        page.addView(stop, LinearLayout.LayoutParams(-1, 50))
        val note = TextView(this).apply {
            text = "Requires RouterOS API-SSL (TCP 8729) reachable remotely. Use a VPN or firewall allowlist. Keep this app's battery usage unrestricted."
            textSize=12f; setTextColor(Color.GRAY); setPadding(2,16,2,0)
        }
        page.addView(note)
        start.setOnClickListener {
            if (host.text.isBlank() || user.text.isBlank() || target.text.isBlank() || pass.text.isBlank()) {
                Toast.makeText(this, "Fill in all connection fields", Toast.LENGTH_LONG).show(); return@setOnClickListener
            }
            val p = port.text.toString().toIntOrNull() ?: 8729
            val i = Intent(this, MonitorService::class.java).apply {
                action = "START"
                putExtra("host", host.text.toString().trim())
                putExtra("port", p)
                putExtra("user", user.text.toString())
                putExtra("pass", pass.text.toString())
                putExtra("target", target.text.toString().trim())
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            status.text = "Starting connection… check the persistent notification."
        }
        stop.setOnClickListener {
            stopService(Intent(this, MonitorService::class.java))
            status.text = "Monitoring stopped"
        }
        setContentView(ScrollView(this).apply { addView(page) })
    }
}
