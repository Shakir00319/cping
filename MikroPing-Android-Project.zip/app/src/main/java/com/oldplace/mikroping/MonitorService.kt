package com.oldplace.mikroping

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import java.io.*
import java.net.Socket
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import kotlin.concurrent.thread

class MonitorService : Service() {
    @Volatile private var running = false
    private var worker: Thread? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val channel = "mikroping_monitor"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (running) return START_STICKY
        createChannel()
        startForeground(11, notification("Connecting to MikroTik…"))
        val host = intent?.getStringExtra("host") ?: return START_NOT_STICKY
        val port = intent.getIntExtra("port", 8729)
        val user = intent.getStringExtra("user") ?: ""
        val pass = intent.getStringExtra("pass") ?: ""
        val target = intent.getStringExtra("target") ?: ""
        running = true
        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MikroPing:Monitor").apply { acquire() }
        worker = thread(name = "MikroPingWorker") {
            var lossAlert = false
            while (running) {
                try {
                    RouterApi(host, port, user, pass).use { api ->
                        api.login()
                        update("Connected • monitoring $target")
                        while (running) {
                            val result = api.ping(target)
                            val lost = result.first
                            val sent = result.second
                            val pct = if (sent == 0) 100 else (lost * 100 / sent)
                            if (pct > 0 && !lossAlert) {
                                notifyEvent("Packet loss detected", "$target: $pct% loss ($lost/$sent packets)")
                                lossAlert = true
                            } else if (pct == 0 && lossAlert) {
                                notifyEvent("Connection recovered", "$target: no packet loss in latest test")
                                lossAlert = false
                            }
                            update("Connected • $target • loss $pct% • ${sent-lost}/$sent replies")
                            Thread.sleep(10000)
                        }
                    }
                } catch (e: Exception) {
                    update("Disconnected: ${e.message ?: "connection error"} • retrying")
                    Thread.sleep(8000)
                }
            }
        }
        return START_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(channel, "MikroPing monitoring", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }
    private fun notification(msg: String): android.app.Notification =
        NotificationCompat.Builder(this, channel).setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("MikroPing").setContentText(msg).setOngoing(true).build()
    private fun update(msg: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(11, notification(msg))
    }
    private fun notifyEvent(title: String, msg: String) {
        val n = NotificationCompat.Builder(this, channel).setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle(title).setContentText(msg).setAutoCancel(true).build()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify((System.currentTimeMillis()%100000).toInt(), n)
    }
    override fun onDestroy() {
        running = false
        try { wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
        super.onDestroy()
    }
}

private class RouterApi(host: String, port: Int, private val username: String, private val password: String) : Closeable {
    private val socket: SSLSocket = (SSLSocketFactory.getDefault() as SSLSocketFactory)
        .createSocket(host, port) as SSLSocket
    private val input = BufferedInputStream(socket.getInputStream())
    private val output = BufferedOutputStream(socket.getOutputStream())

    init { socket.soTimeout = 15000; socket.startHandshake() }

    fun login() {
        send(listOf("/login", "=name=$username", "=password=$password"))
        val r = readReply()
        if (r.any { it.startsWith("!trap") }) throw IOException("RouterOS login rejected; check username/password and API permissions")
    }

    fun ping(target: String): Pair<Int, Int> {
        send(listOf("/ping", "=address=$target", "=count=5", "=interval=300ms"))
        var sent = 0
        var lost = 0
        while (true) {
            val words = readSentence()
            if (words.isEmpty()) continue
            if (words[0] == "!re") {
                sent++
                if (words.any { it == "=status=timeout" }) lost++
            }
            if (words[0] == "!trap") throw IOException(words.joinToString(" "))
            if (words[0] == "!done") break
        }
        // Count explicit timeout records; if RouterOS omits timeout rows, missing probes are treated as lost.
        if (sent < 5) lost += (5 - sent)
        return Pair(lost.coerceIn(0, 5), 5)
    }

    private fun send(words: List<String>) {
        for (w in words) writeWord(w)
        output.write(0); output.flush()
    }
    private fun writeWord(s: String) {
        val b = s.toByteArray(Charsets.UTF_8); writeLength(b.size); output.write(b)
    }
    private fun writeLength(n: Int) {
        when {
            n < 0x80 -> output.write(n)
            n < 0x4000 -> { output.write((n shr 8) or 0x80); output.write(n) }
            n < 0x200000 -> { output.write((n shr 16) or 0xC0); output.write(n shr 8); output.write(n) }
            n < 0x10000000 -> { output.write((n shr 24) or 0xE0); output.write(n shr 16); output.write(n shr 8); output.write(n) }
            else -> { output.write(0xF0); output.write(n shr 24); output.write(n shr 16); output.write(n shr 8); output.write(n) }
        }
    }
    private fun readLength(): Int {
        val c = input.read(); if (c < 0) throw EOFException()
        return when {
            c and 0x80 == 0 -> c
            c and 0xC0 == 0x80 -> ((c and 0x3F) shl 8) or readByte()
            c and 0xE0 == 0xC0 -> ((c and 0x1F) shl 16) or (readByte() shl 8) or readByte()
            c and 0xF0 == 0xE0 -> ((c and 0x0F) shl 24) or (readByte() shl 16) or (readByte() shl 8) or readByte()
            else -> (readByte() shl 24) or (readByte() shl 16) or (readByte() shl 8) or readByte()
        }
    }
    private fun readByte(): Int { val v=input.read(); if(v<0) throw EOFException(); return v }
    private fun readSentence(): List<String> {
        val words = mutableListOf<String>()
        while (true) {
            val len = readLength()
            if (len == 0) break
            val b = ByteArray(len); var off=0
            while(off<len) { val n=input.read(b,off,len-off); if(n<0) throw EOFException(); off+=n }
            words.add(String(b, Charsets.UTF_8))
        }
        return words
    }
    private fun readReply(): List<String> {
        val all = mutableListOf<String>()
        while (true) { val s=readSentence(); all.addAll(s); if(s.firstOrNull()=="!done") break; if(s.firstOrNull()=="!trap") break }
        return all
    }
    override fun close() { try { socket.close() } catch (_: Exception) {} }
}
