# MikroPing Android project

An Android Studio starter app for remote RouterOS API-SSL monitoring.

## Build
Open this folder in Android Studio, allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Router requirements
- Enable RouterOS API-SSL (normally TCP 8729).
- Use a dedicated RouterOS user with only the permissions needed for API login and ping.
- Prefer WireGuard VPN or another VPN. Do not expose the router management API to the entire public internet.
- The TLS certificate must be trusted by Android. This starter uses normal certificate validation and will reject self-signed/untrusted certificates.
- Allow the VPN/client source in the router firewall.
- Disable battery optimization for MikroPing on the phone and allow notifications.

## Important limitations
This is a starter source project, not a prebuilt or tested APK. It needs a real RouterOS device and trusted TLS certificate for end-to-end testing. Android may still stop background work under severe power or manufacturer restrictions. The service uses a persistent foreground notification and partial wake lock, but cannot guarantee operation after force-stop, reboot without additional setup, or battery exhaustion.
