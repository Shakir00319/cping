# Router Ping Watch

Simple Android app that pings your MikroTik every N seconds (a short burst of pings),
shows the packet loss, and raises a loud notification when loss is at or above your threshold.

## Build
1. Install Android Studio. File > Open > select this folder, let Gradle sync
   (if asked to upgrade the Android Gradle Plugin, accept).
2. Plug in your phone (USB debugging on) and press Run,
   or Build > Build APK(s) and install the APK from app/build/outputs/apk/debug/.

## Use
- Phone must be on the router's Wi-Fi. Enter the router IP (default 192.168.88.1).
- Defaults: 10 pings every 30 s, alert when loss >= 1% (any lost ping).
- Allow notifications. Set the app's battery usage to Unrestricted so it keeps checking with the screen off.
