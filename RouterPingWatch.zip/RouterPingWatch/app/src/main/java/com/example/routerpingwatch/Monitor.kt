package com.example.routerpingwatch

data class Result(
    val time: String,
    val sent: Int,
    val received: Int,
    val loss: Double,
    val avgMs: Double?
)

/** Shared state between the background service and the screen (same process). */
object Monitor {
    @Volatile var running = false
    @Volatile var host = ""
    @Volatile var threshold = 1.0
    @Volatile var last: Result? = null
    @Volatile var totalSent = 0L
    @Volatile var totalLost = 0L
    @Volatile var onChange: (() -> Unit)? = null

    private val log = ArrayDeque<String>()

    @Synchronized
    fun reset(host: String, threshold: Double) {
        this.host = host
        this.threshold = threshold
        last = null
        totalSent = 0
        totalLost = 0
        log.clear()
    }

    @Synchronized
    fun record(r: Result) {
        last = r
        totalSent += r.sent
        totalLost += (r.sent - r.received)
        val avg = r.avgMs?.let { String.format(java.util.Locale.US, "%.1f ms", it) } ?: "-"
        log.addFirst(
            String.format(
                java.util.Locale.US, "%s   %d/%d   %3.0f%%   %s",
                r.time, r.received, r.sent, r.loss, avg
            )
        )
        while (log.size > 40) log.removeLast()
        onChange?.invoke()
    }

    @Synchronized
    fun logText(): String = log.joinToString("\n")

    fun changed() {
        onChange?.invoke()
    }
}
