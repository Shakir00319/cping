package com.example.routerpingwatch

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MonitorService : Service() {

    companion object {
        const val EXTRA_HOST = "host"
        const val EXTRA_BURST = "burst"
        const val EXTRA_INTERVAL = "interval"
        const val EXTRA_THRESHOLD = "threshold"
        const val ACTION_STOP = "com.example.routerpingwatch.STOP"

        private const val CH_MONITOR = "monitor"
        private const val CH_ALERT = "alert"
        private const val ID_MONITOR = 1
        private const val ID_ALERT = 2
        private const val ALERT_COOLDOWN_MS = 5 * 60 * 1000L
    }

    @Volatile private var running = false
    private var worker: Thread? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        createChannels()
        ServiceCompat.startForeground(
            this, ID_MONITOR, ongoing("Starting..."),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
        if (running) return START_NOT_STICKY

        val host = intent.getStringExtra(EXTRA_HOST) ?: "192.168.88.1"
        val burst = intent.getIntExtra(EXTRA_BURST, 10).coerceIn(1, 50)
        val interval = intent.getIntExtra(EXTRA_INTERVAL, 30).coerceIn(10, 3600)
        val threshold = intent.getDoubleExtra(EXTRA_THRESHOLD, 1.0)

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "routerpingwatch:monitor")
            .also { it.acquire() }

        Monitor.reset(host, threshold)
        Monitor.running = true
        running = true
        Monitor.changed()

        worker = Thread { loop(host, burst, interval, threshold) }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun loop(host: String, burst: Int, interval: Int, threshold: Double) {
        var alerting = false
        var lastAlert = 0L
        val nm = getSystemService(NotificationManager::class.java)

        while (running) {
            val t0 = System.currentTimeMillis()
            val r = runBurst(host, burst) ?: return
            if (!running) return
            Monitor.record(r)

            val avg = r.avgMs?.let { String.format(Locale.US, "%.0f ms", it) } ?: "-"
            nm.notify(
                ID_MONITOR,
                ongoing("$host: ${r.loss.toInt()}% loss, avg $avg (${r.time})")
            )

            val now = System.currentTimeMillis()
            if (r.loss >= threshold) {
                alerting = true
                if (now - lastAlert >= ALERT_COOLDOWN_MS) {
                    lastAlert = now
                    nm.notify(ID_ALERT, alertNotification(host, r))
                }
            } else if (alerting) {
                alerting = false
                lastAlert = 0L
                nm.notify(ID_ALERT, recoveredNotification(host, r))
            }

            var wait = interval * 1000L - (System.currentTimeMillis() - t0)
            while (running && wait > 0) {
                val s = minOf(wait, 500L)
                try {
                    Thread.sleep(s)
                } catch (e: InterruptedException) {
                    return
                }
                wait -= s
            }
        }
    }

    /** Sends [count] pings, 200 ms apart. Returns null if interrupted. */
    private fun runBurst(host: String, count: Int): Result? {
        var sent = 0
        var ok = 0
        var sum = 0.0
        for (i in 0 until count) {
            if (!running) return null
            val rtt = Pinger.once(host)
            sent++
            if (rtt != null) {
                ok++
                sum += rtt
            }
            if (i < count - 1) {
                try {
                    Thread.sleep(200)
                } catch (e: InterruptedException) {
                    return null
                }
            }
        }
        val loss = 100.0 * (sent - ok) / sent
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        return Result(time, sent, ok, loss, if (ok > 0) sum / ok else null)
    }

    override fun onDestroy() {
        running = false
        worker?.interrupt()
        wakeLock?.let { if (it.isHeld) it.release() }
        Monitor.running = false
        Monitor.changed()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- notifications

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_MONITOR, "Monitoring status", NotificationManager.IMPORTANCE_LOW)
        )
        val alert = NotificationChannel(
            CH_ALERT, "Packet loss alerts", NotificationManager.IMPORTANCE_HIGH
        ).apply {
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 500, 250, 500, 250, 500)
        }
        nm.createNotificationChannel(alert)
    }

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        this, 1, Intent(this, MainActivity::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun ongoing(text: String): Notification {
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, MonitorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CH_MONITOR)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("Watching router")
            .setContentText(text)
            .setContentIntent(openApp())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Stop", stop)
            .build()
    }

    private fun alertNotification(host: String, r: Result): Notification {
        val down = r.loss >= 100.0
        return NotificationCompat.Builder(this, CH_ALERT)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle(if (down) "Router not responding" else "Packet loss detected")
            .setContentText("$host: ${r.received}/${r.sent} replies, ${r.loss.toInt()}% loss (${r.time})")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setContentIntent(openApp())
            .setAutoCancel(true)
            .build()
    }

    private fun recoveredNotification(host: String, r: Result): Notification =
        NotificationCompat.Builder(this, CH_ALERT)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("Router recovered")
            .setContentText("$host: packet loss cleared (${r.time})")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(openApp())
            .setAutoCancel(true)
            .build()
}
