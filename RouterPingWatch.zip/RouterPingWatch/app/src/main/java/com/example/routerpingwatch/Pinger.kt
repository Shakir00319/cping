package com.example.routerpingwatch

import java.util.concurrent.TimeUnit

object Pinger {
    private val rttRegex = Regex("time[=<]\\s*([0-9.]+)")

    /**
     * Sends one ICMP ping using the phone's built-in ping tool (no root needed on most phones).
     * Returns the round-trip time in ms, or null if the packet was lost.
     */
    fun once(host: String): Double? {
        return try {
            val p = ProcessBuilder("/system/bin/ping", "-c", "1", "-W", "1", host)
                .redirectErrorStream(true)
                .start()
            if (!p.waitFor(4, TimeUnit.SECONDS)) {
                p.destroy()
                return null
            }
            val out = p.inputStream.bufferedReader().readText()
            if (p.exitValue() != 0) return null
            rttRegex.find(out)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
        } catch (e: Exception) {
            null
        }
    }
}
