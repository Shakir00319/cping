package com.example.routerpingwatch

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var hostIn: EditText
    private lateinit var burstIn: EditText
    private lateinit var intervalIn: EditText
    private lateinit var thresholdIn: EditText
    private lateinit var toggle: Button
    private lateinit var lossText: TextView
    private lateinit var statusText: TextView
    private lateinit var totalsText: TextView
    private lateinit var logText: TextView

    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        hostIn = findViewById(R.id.hostIn)
        burstIn = findViewById(R.id.burstIn)
        intervalIn = findViewById(R.id.intervalIn)
        thresholdIn = findViewById(R.id.thresholdIn)
        toggle = findViewById(R.id.toggle)
        lossText = findViewById(R.id.lossText)
        statusText = findViewById(R.id.statusText)
        totalsText = findViewById(R.id.totalsText)
        logText = findViewById(R.id.logText)

        hostIn.setText(prefs.getString("host", "192.168.88.1"))
        burstIn.setText(prefs.getInt("burst", 10).toString())
        intervalIn.setText(prefs.getInt("interval", 30).toString())
        thresholdIn.setText(prefs.getString("threshold", "1"))

        toggle.setOnClickListener { if (Monitor.running) stopMonitoring() else startMonitoring() }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onStart() {
        super.onStart()
        Monitor.onChange = { runOnUiThread { render() } }
        render()
    }

    override fun onStop() {
        Monitor.onChange = null
        super.onStop()
    }

    private fun startMonitoring() {
        val host = hostIn.text.toString().trim()
        if (!Regex("^[A-Za-z0-9][A-Za-z0-9._:-]*$").matches(host)) {
            Toast.makeText(this, "Enter a valid router IP or hostname", Toast.LENGTH_SHORT).show()
            return
        }
        val burst = (burstIn.text.toString().toIntOrNull() ?: 10).coerceIn(1, 50)
        val interval = (intervalIn.text.toString().toIntOrNull() ?: 30).coerceIn(10, 3600)
        val threshold = (thresholdIn.text.toString().toDoubleOrNull() ?: 1.0).coerceIn(0.1, 100.0)

        burstIn.setText(burst.toString())
        intervalIn.setText(interval.toString())
        thresholdIn.setText(threshold.toString().removeSuffix(".0"))

        prefs.edit()
            .putString("host", host)
            .putInt("burst", burst)
            .putInt("interval", interval)
            .putString("threshold", threshold.toString().removeSuffix(".0"))
            .apply()

        val i = Intent(this, MonitorService::class.java)
            .putExtra(MonitorService.EXTRA_HOST, host)
            .putExtra(MonitorService.EXTRA_BURST, burst)
            .putExtra(MonitorService.EXTRA_INTERVAL, interval)
            .putExtra(MonitorService.EXTRA_THRESHOLD, threshold)
        startForegroundService(i)
        Monitor.running = true
        render()
    }

    private fun stopMonitoring() {
        stopService(Intent(this, MonitorService::class.java))
        Monitor.running = false
        render()
    }

    private fun render() {
        val running = Monitor.running
        toggle.text = if (running) "Stop" else "Start monitoring"
        for (e in listOf(hostIn, burstIn, intervalIn, thresholdIn)) e.isEnabled = !running

        val r = Monitor.last
        if (r == null) {
            lossText.text = "—"
            lossText.setTextColor(Color.parseColor("#44607E"))
            statusText.text = if (running) "Checking..." else "Not running"
            totalsText.text = ""
            logText.text = ""
            return
        }

        val bad = r.loss >= Monitor.threshold
        lossText.text = String.format(Locale.US, "%.0f%%", r.loss)
        lossText.setTextColor(Color.parseColor(if (bad) "#C62828" else "#1B8A3A"))

        val avg = r.avgMs?.let { String.format(Locale.US, "%.1f ms", it) } ?: "no replies"
        statusText.text = "${r.received}/${r.sent} replies, avg $avg"

        val total = Monitor.totalSent
        val lost = Monitor.totalLost
        val pct = if (total > 0) 100.0 * lost / total else 0.0
        totalsText.text = String.format(
            Locale.US, "Since start: %d of %d lost (%.1f%%)", lost, total, pct
        )
        logText.text = Monitor.logText()
    }
}
